ZMCameraLib
===========

A library for communicating with cameras of the ZM type, like 
[ZM 0.3Mpixels from dfrobot](http://www.dfrobot.com/wiki/index.php/0.3M_pixel_serial_JPEG_camera_module_%EF%BC%88SKU%EF%BC%9ASEN0099%EF%BC%89)

Maybe working with the [C429 camera](http://www.si-cube.com/Products/cctvequipment/24/), to be checked
